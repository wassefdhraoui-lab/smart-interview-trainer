import Link from "next/link";
import NavbarAvatar from "./NavbarAvatar";

type NavbarProps = {
  avatar?: string;
};

export default function Navbar({ avatar = "" }: NavbarProps) {
  return (
    <nav className="fixed left-0 top-0 z-50 w-full border-b border-[#EDEEF2] bg-white/95 backdrop-blur-sm">
      <div className="mx-auto flex max-w-7xl items-center justify-between px-8 py-4">
        <Link href="/" className="text-xl font-bold text-[#111827]">
          Smart Interview Trainer
        </Link>

        <div className="flex items-center gap-6">
          <Link href="/dashboard" className="font-semibold text-[#6B7280]">
            Dashboard
          </Link>

          <Link href="/interview-setup" className="font-semibold text-[#6B7280]">
            Practice
          </Link>

          <Link href="/progress" className="font-semibold text-[#6B7280]">
            Progress
          </Link>

          <span>🔔</span>

          <NavbarAvatar />

          <Link
            href="/login"
            className="rounded-xl bg-[#4F46E5] px-5 py-3 font-semibold text-white transition hover:bg-[#6366F1]"
          >
            Login
          </Link>
        </div>
      </div>
    </nav>
  );
}