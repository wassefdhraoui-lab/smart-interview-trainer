import Link from "next/link";
import Navbar from "../../components/Navbar";

export default function ProgressPage() {
  return (
    <>
      <Navbar />

      <main className="min-h-screen bg-[#FFFFFF] px-8 py-12 text-[#111827]">
        <div className="mx-auto max-w-7xl">
          <div className="mb-8">
            <p className="text-sm font-semibold text-[#4F46E5]">Progress</p>

            <h1 className="mt-2 text-[2.5rem] font-extrabold tracking-[-0.02em]">
              Progress Overview
            </h1>

            <p className="mt-3 text-lg leading-[1.6] text-[#6B7280]">
              Track your improvement, review old interviews, and continue with
              targeted practice.
            </p>
          </div>

          <section className="mb-8 rounded-3xl border border-[#EDEEF2] bg-[#F5F6FA] p-6 shadow-sm">
            <div className="flex flex-wrap gap-4">
              <select className="rounded-xl border border-[#EDEEF2] bg-white px-4 py-3 font-semibold text-[#111827] outline-none focus:border-[#4F46E5]">
                <option>All categories</option>
                <option>Java</option>
                <option>SQL</option>
                <option>HR</option>
              </select>

              <select className="rounded-xl border border-[#EDEEF2] bg-white px-4 py-3 font-semibold text-[#111827] outline-none focus:border-[#4F46E5]">
                <option>30d</option>
                <option>7d</option>
                <option>90d</option>
              </select>
            </div>
          </section>

          <section className="grid gap-8 lg:grid-cols-2">
            <div className="rounded-3xl border border-[#EDEEF2] bg-[#F5F6FA] p-8 shadow-sm">
              <h2 className="text-2xl font-bold text-[#111827]">
                Score over time
              </h2>

              <div className="mt-6 flex h-72 items-center justify-center rounded-2xl border border-[#EDEEF2] bg-white text-[#6B7280]">
                Line Chart Placeholder
              </div>
            </div>

            <div className="rounded-3xl border border-[#EDEEF2] bg-[#F5F6FA] p-8 shadow-sm">
              <h2 className="text-2xl font-bold text-[#111827]">
                Performance by category
              </h2>

              <div className="mt-6 space-y-5">
                {[
                  ["Java", "85%", "#10B981"],
                  ["SQL", "78%", "#F59E0B"],
                  ["HR", "62%", "#EF4444"],
                ].map(([category, score, color]) => (
                  <div key={category}>
                    <div className="mb-2 flex justify-between text-sm text-[#6B7280]">
                      <span>{category}</span>
                      <span>{score}</span>
                    </div>

                    <div className="h-3 rounded-full bg-[#EDEEF2]">
                      <div
                        className="h-3 rounded-full"
                        style={{ width: score, backgroundColor: color }}
                      />
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </section>

          <section className="mt-8 rounded-3xl border border-[#EDEEF2] bg-[#F5F6FA] p-8 shadow-sm">
            <div className="flex items-center justify-between">
              <div>
                <h2 className="text-2xl font-bold text-[#111827]">
                  Recommended next practice
                </h2>

                <p className="mt-2 text-[#6B7280]">
                  HR is currently your weakest category.
                </p>
              </div>

              <Link
                href="/interview-setup"
                className="rounded-xl bg-[#4F46E5] px-6 py-3 font-semibold text-white transition hover:bg-[#6366F1]"
              >
                Practice HR →
              </Link>
            </div>
          </section>

          <section className="mt-8 rounded-3xl border border-[#EDEEF2] bg-[#F5F6FA] p-8 shadow-sm">
            <h2 className="text-2xl font-bold text-[#111827]">
              Interview history
            </h2>

            <div className="mt-6 space-y-4">
              {["Java Interview", "SQL Interview", "HR Interview"].map((item) => (
                <div
                  key={item}
                  className="flex items-center justify-between rounded-xl border border-[#EDEEF2] bg-white p-4"
                >
                  <span className="font-semibold text-[#111827]">{item}</span>

                  <Link
                    href="/feedback"
                    className="rounded-lg bg-[#4F46E5] px-4 py-2 font-semibold text-white transition hover:bg-[#6366F1]"
                  >
                    Review
                  </Link>
                </div>
              ))}
            </div>
          </section>
        </div>
      </main>
    </>
  );
}