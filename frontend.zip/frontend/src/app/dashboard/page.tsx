"use client";

import { useState } from "react";
import Link from "next/link";
import Navbar from "../../components/Navbar";
import { useUser } from "../../context/UserContext";

const categories = ["Java", "SQL", "HR", "Algorithms", "Web Development"];

const interviews = [
  { title: "Java Interview", score: 85, category: "Java" },
  { title: "SQL Interview", score: 78, category: "SQL" },
  { title: "HR Interview", score: 82, category: "HR" },
];

export default function DashboardPage() {
  const { user } = useUser();

  const [selectedCategory, setSelectedCategory] = useState("Java");

  const [orbPosition, setOrbPosition] = useState({
    x: 0,
    y: 0,
    visible: false,
  });

  return (
    <>
      <Navbar />

      <main className="min-h-screen bg-[#FFFFFF] px-8 py-12 text-[#111827]">
        <div className="mx-auto max-w-7xl">
          <section
            onMouseMove={(event) => {
              const rect = event.currentTarget.getBoundingClientRect();

              setOrbPosition({
                x: event.clientX - rect.left,
                y: event.clientY - rect.top,
                visible: true,
              });
            }}
            onMouseLeave={() => {
              setOrbPosition((previousPosition) => ({
                ...previousPosition,
                visible: false,
              }));
            }}
            className="relative mb-10 overflow-hidden rounded-3xl border border-[#EDEEF2] border-l-4 border-l-[#4F46E5] bg-[#EEF2FF] p-8 shadow-sm"
          >
            <div
              className="pointer-events-none absolute h-[280px] w-[280px] rounded-full transition-[left,top,opacity] duration-300 ease-out"
              style={{
                left: orbPosition.x,
                top: orbPosition.y,
                opacity: orbPosition.visible ? 1 : 0,
                transform: "translate(-50%, -50%)",
                background:
                  "radial-gradient(circle, rgba(99, 102, 241, 0.25) 0%, rgba(99, 102, 241, 0) 70%)",
              }}
            />

            <div className="relative z-10 flex items-center justify-between gap-10">
              <div>
                <p className="text-sm font-semibold text-[#4F46E5]">
                  Dashboard
                </p>

                <h1 className="mt-2 text-[2.5rem] font-extrabold tracking-[-0.02em] text-[#111827]">
                  Welcome back, {user?.name || "User"}
                </h1>

                <p className="mt-4 max-w-2xl text-lg text-[#6B7280]">
                  Check your progress, review previous interviews and start a
                  new practice session.
                </p>

                <div className="mt-8">
                  <Link
                    href="/interview-setup"
                    className="rounded-xl bg-[#4F46E5] px-6 py-3 font-semibold text-white transition hover:bg-[#6366F1]"
                  >
                    + Start Interview
                  </Link>
                </div>
              </div>

              {user?.avatar&& (
                
                  <div className="flex items-center justify-center">
                    <img
                      src={`/${user.avatar}`}
                      alt="User avatar"
                      className="h-28 w-28 rounded-full border-4 border-white object-cover shadow-lg"
                    />
                  </div>
                              )}
            </div>
          </section>

          <section className="mb-8 grid gap-6 md:grid-cols-4">
            <div className="rounded-3xl border border-[#EDEEF2] bg-white p-6 shadow-sm transition duration-200 ease-in-out hover:-translate-y-[3px] hover:shadow-[0_8px_24px_rgba(79,70,229,0.12)]">
              <p className="text-xs font-medium uppercase tracking-[0.08em] text-[#9CA3AF]">
                Avg Score
              </p>
              <h2 className="mt-3 text-[1.75rem] font-bold text-[#10B981]">
                82%
              </h2>
              <div className="mt-4 h-2 rounded-full bg-[#EDEEF2]">
                <div className="h-2 w-[82%] rounded-full bg-[#10B981]" />
              </div>
            </div>

            <div className="rounded-3xl border border-[#EDEEF2] bg-white p-6 shadow-sm transition duration-200 ease-in-out hover:-translate-y-[3px] hover:shadow-[0_8px_24px_rgba(79,70,229,0.12)]">
              <p className="text-xs font-medium uppercase tracking-[0.08em] text-[#9CA3AF]">
                Completed
              </p>
              <h2 className="mt-3 text-[1.75rem] font-bold text-[#111827]">
                5
              </h2>
              <p className="mt-2 text-sm text-[#10B981]">+2 this week</p>
            </div>

            <div className="rounded-3xl border border-[#EDEEF2] bg-white p-6 shadow-sm transition duration-200 ease-in-out hover:-translate-y-[3px] hover:shadow-[0_8px_24px_rgba(79,70,229,0.12)]">
              <p className="text-xs font-medium uppercase tracking-[0.08em] text-[#9CA3AF]">
                Best Category
              </p>
              <h2 className="mt-3 text-[1.75rem] font-bold text-[#10B981]">
                Java
              </h2>
              <p className="mt-2 text-sm text-[#6B7280]">
                Strong performance
              </p>
            </div>

            <div className="rounded-3xl border border-[#EDEEF2] bg-white p-6 shadow-sm transition duration-200 ease-in-out hover:-translate-y-[3px] hover:shadow-[0_8px_24px_rgba(79,70,229,0.12)]">
              <p className="text-xs font-medium uppercase tracking-[0.08em] text-[#9CA3AF]">
                Weakest Category
              </p>
              <h2 className="mt-3 text-[1.75rem] font-bold text-[#EF4444]">
                Algorithms
              </h2>
              <p className="mt-2 text-sm text-[#EF4444]">
                Needs improvement
              </p>
            </div>
          </section>

          <section className="mb-8 rounded-3xl border border-[#EDEEF2] bg-[#F5F6FA] p-8 shadow-sm">
            <h2 className="text-2xl font-bold text-[#111827]">
              Choose Practice Category
            </h2>

            <div className="mt-6 flex flex-wrap gap-3">
              {categories.map((category) => (
                <button
                  key={category}
                  onClick={() => setSelectedCategory(category)}
                  className={`rounded-xl border px-5 py-3 font-semibold transition duration-150 ${
                    selectedCategory === category
                      ? "border-[#4F46E5] bg-[#4F46E5] text-white"
                      : "border-[#EDEEF2] bg-[#F5F6FA] text-[#111827] hover:bg-[#EEF2FF] hover:text-[#4F46E5]"
                  }`}
                >
                  {category}
                </button>
              ))}
            </div>

            <div className="mt-6 flex items-center justify-between rounded-2xl border border-[#EDEEF2] bg-white p-6">
              <div>
                <p className="text-sm font-semibold text-[#4F46E5]">
                  Selected Category
                </p>

                <h3 className="mt-2 text-2xl font-bold text-[#111827]">
                  {selectedCategory} Interview Practice
                </h3>

                <p className="mt-2 text-[#6B7280]">
                  Focused practice questions for this category.
                </p>
              </div>

              <Link
                href="/interview-setup"
                className="rounded-xl bg-[#4F46E5] px-6 py-3 font-semibold text-white transition hover:bg-[#6366F1]"
              >
                Start Setup
              </Link>
            </div>
          </section>

          <section className="rounded-3xl border border-[#EDEEF2] bg-[#F5F6FA] p-8 shadow-sm">
            <div className="mb-6 flex items-center justify-between">
              <h2 className="text-2xl font-bold text-[#111827]">
                Recent Interviews
              </h2>

              <Link href="/progress" className="font-semibold text-[#4F46E5]">
                View all →
              </Link>
            </div>

            <div className="space-y-4">
              {interviews.map((interview) => (
                <div
                  key={interview.title}
                  className="flex items-center justify-between rounded-xl border border-[#EDEEF2] bg-white p-4"
                >
                  <div>
                    <p className="font-semibold text-[#111827]">
                      {interview.title}
                    </p>

                    <p className="text-sm text-[#6B7280]">
                      {interview.category}
                    </p>
                  </div>

                  <div className="flex items-center gap-4">
                    <span
                      className={`font-bold ${
                        interview.score >= 80
                          ? "text-[#10B981]"
                          : interview.score >= 60
                          ? "text-[#F59E0B]"
                          : "text-[#EF4444]"
                      }`}
                    >
                      {interview.score}%
                    </span>

                    <Link
                      href="/feedback"
                      className="rounded-lg bg-[#4F46E5] px-4 py-2 font-semibold text-white transition hover:bg-[#6366F1]"
                    >
                      Review
                    </Link>
                  </div>
                </div>
              ))}
            </div>
          </section>
        </div>
      </main>
    </>
  );
}
