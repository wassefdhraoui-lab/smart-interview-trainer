import Link from "next/link";
import Navbar from "../../components/Navbar";

export default function InterviewPage() {
  return (
    <>
      <Navbar />

      <main className="min-h-screen bg-[#FFFFFF] px-8 py-12 text-[#111827]">
        <div className="mx-auto max-w-4xl">
          <div className="mb-6 flex items-center justify-between">
            <Link href="/dashboard" className="font-semibold text-[#4F46E5]">
              ← Exit
            </Link>

            <div className="font-semibold text-[#6B7280]">
              Java · Intermediate · Q 3 / 5
            </div>
          </div>

          <div className="mb-8 h-3 rounded-full bg-[#EDEEF2]">
            <div className="h-3 w-[60%] rounded-full bg-[#4F46E5]" />
          </div>

          <section className="rounded-3xl border border-[#EDEEF2] bg-[#F5F6FA] p-8 shadow-sm">
            <h1 className="text-[2.5rem] font-extrabold tracking-[-0.02em] text-[#111827]">
              Question
            </h1>

            <p className="mt-4 text-xl leading-[1.6] text-[#6B7280]">
              Explain the difference between an abstract class and an interface.
            </p>

            <textarea
              className="mt-8 h-44 w-full rounded-2xl border border-[#EDEEF2] bg-white p-4 text-[#111827] outline-none placeholder:text-[#9CA3AF] focus:border-[#4F46E5]"
              placeholder="Type your answer here..."
            />

            <div className="mt-6 flex gap-4">
              <button className="rounded-xl bg-[#10B981] px-5 py-3 font-semibold text-white transition hover:opacity-90">
                🎤 Start Voice
              </button>

              <button className="rounded-xl bg-[#EF4444] px-5 py-3 font-semibold text-white transition hover:opacity-90">
                ⏹ Stop Recording
              </button>

              <span className="rounded-xl border border-[#EDEEF2] bg-white px-5 py-3 font-semibold text-[#6B7280]">
                00:14
              </span>
            </div>

            <div className="mt-6 rounded-2xl border border-dashed border-[#EDEEF2] bg-white p-5 text-[#6B7280]">
              Transcript editable: “An abstract class can have…”
            </div>

            <div className="mt-8 flex justify-end gap-4">
              <button className="rounded-xl border border-[#EDEEF2] bg-white px-6 py-3 font-semibold text-[#111827] transition hover:bg-[#F5F6FA]">
                Skip
              </button>

              <Link
                href="/feedback"
                className="rounded-xl bg-[#4F46E5] px-6 py-3 font-semibold text-white transition hover:bg-[#6366F1]"
              >
                Submit Answer
              </Link>
            </div>
          </section>
        </div>
      </main>
    </>
  );
}