import Link from "next/link";
import Navbar from "../../components/Navbar";

export default function FeedbackPage() {
  return (
    <>
      <Navbar />

      <main className="min-h-screen bg-[#FFFFFF] px-8 py-12 text-[#111827]">
        <div className="mx-auto max-w-4xl">
          <section className="rounded-3xl border border-[#EDEEF2] bg-[#F5F6FA] p-8 shadow-sm">
            <p className="text-sm font-semibold text-[#4F46E5]">
              Interview Complete · Java · Intermediate · 5 Q
            </p>

            <div className="mt-6 text-center">
              <h1 className="text-[2.5rem] font-extrabold tracking-[-0.02em] text-[#10B981]">
                78%
              </h1>
              <p className="mt-2 text-xl text-[#6B7280]">Good Performance</p>
            </div>

            <div className="mt-10 grid gap-6 md:grid-cols-2">
              <div className="rounded-2xl border border-[#EDEEF2] bg-white p-6">
                <h2 className="text-xl font-bold text-[#111827]">Strengths</h2>
                <ul className="mt-4 space-y-2 text-[#10B981]">
                  <li>✓ Clear explanations</li>
                  <li>✓ Good Java fundamentals</li>
                  <li>✓ Strong SQL knowledge</li>
                </ul>
              </div>

              <div className="rounded-2xl border border-[#EDEEF2] bg-white p-6">
                <h2 className="text-xl font-bold text-[#111827]">
                  Areas to Improve
                </h2>
                <ul className="mt-4 space-y-2 text-[#F59E0B]">
                  <li>• More detailed answers</li>
                  <li>• Explain algorithms deeper</li>
                  <li>• Use more technical examples</li>
                </ul>
              </div>
            </div>

            <h2 className="mt-10 text-2xl font-bold text-[#111827]">
              Question Feedback
            </h2>

            {[1, 2].map((number) => (
              <div
                key={number}
                className="mt-4 rounded-2xl border border-[#EDEEF2] bg-white p-6"
              >
                <div className="flex justify-between">
                  <h3 className="font-bold text-[#111827]">Question {number}</h3>
                  <span
                    className={`font-bold ${
                      number === 1 ? "text-[#10B981]" : "text-[#F59E0B]"
                    }`}
                  >
                    {number === 1 ? "85%" : "70%"}
                  </span>
                </div>

                <p className="mt-3 text-[#10B981]">
                  Covered ✓ inheritance, overriding
                </p>

                <p className="mt-2 text-[#EF4444]">
                  Missed ✗ runtime polymorphism
                </p>

                <button className="mt-4 font-semibold text-[#4F46E5]">
                  Sample answer ▾ expand
                </button>
              </div>
            ))}

            <div className="mt-8 rounded-2xl border border-[#EDEEF2] bg-white p-6">
              <h2 className="text-xl font-bold text-[#111827]">
                Recommended Next Practice
              </h2>

              <p className="mt-2 text-[#6B7280]">
                Java · Intermediate · Weakest topic detected: Object-Oriented Design
              </p>
            </div>

            <div className="mt-8 flex gap-4">
              <Link
                href="/interview-setup"
                className="rounded-xl bg-[#4F46E5] px-6 py-3 font-semibold text-white transition hover:bg-[#6366F1]"
              >
                Practice Again
              </Link>

              <Link
                href="/progress"
                className="rounded-xl border border-[#EDEEF2] bg-white px-6 py-3 font-semibold text-[#111827] transition hover:bg-[#F5F6FA]"
              >
                View Progress
              </Link>

              <Link
                href="/dashboard"
                className="rounded-xl border border-[#EDEEF2] bg-white px-6 py-3 font-semibold text-[#111827] transition hover:bg-[#F5F6FA]"
              >
                Dashboard
              </Link>
            </div>
          </section>
        </div>
      </main>
    </>
  );
}