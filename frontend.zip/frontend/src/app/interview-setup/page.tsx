"use client";

import { useState } from "react";
import Link from "next/link";
import Navbar from "../../components/Navbar";

const categories = ["Java", "SQL", "HR", "Algorithms", "Web Development"];
const difficulties = ["Beginner", "Intermediate", "Advanced"];
const questionCounts = ["3", "5", "10"];
const modes = ["Text Only", "Voice + Transcript"];

export default function InterviewSetupPage() {
  const [category, setCategory] = useState("Java");
  const [difficulty, setDifficulty] = useState("Beginner");
  const [count, setCount] = useState("5");
  const [mode, setMode] = useState("Voice + Transcript");

  return (
    <>
      <Navbar />

      <main className="min-h-screen bg-[#FFFFFF] px-8 py-12 text-[#111827]">
        <div className="mx-auto max-w-3xl rounded-3xl border border-[#EDEEF2] bg-[#F5F6FA] p-8 shadow-sm">
          <Link href="/dashboard" className="text-sm font-semibold text-[#4F46E5]">
            ← Cancel
          </Link>

          <h1 className="mt-6 text-[2.5rem] font-extrabold tracking-[-0.02em] text-[#111827]">
            Interview Setup
          </h1>

          <div className="mt-8 space-y-8">
            <OptionGroup title="Interview Category" items={categories} value={category} setValue={setCategory} />
            <OptionGroup title="Difficulty" items={difficulties} value={difficulty} setValue={setDifficulty} />
            <OptionGroup title="Number of Questions" items={questionCounts} value={count} setValue={setCount} />
            <OptionGroup title="Answer Mode" items={modes} value={mode} setValue={setMode} />
          </div>

          <div className="mt-10 flex justify-end gap-4">
            <Link
              href="/dashboard"
              className="rounded-xl border border-[#EDEEF2] bg-white px-6 py-3 font-semibold text-[#111827] transition hover:bg-[#F5F6FA]"
            >
              Cancel
            </Link>

            <Link
              href="/interview"
              className="rounded-xl bg-[#4F46E5] px-6 py-3 font-semibold text-white transition hover:bg-[#6366F1]"
            >
              Start Interview
            </Link>
          </div>
        </div>
      </main>
    </>
  );
}

function OptionGroup({
  title,
  items,
  value,
  setValue,
}: {
  title: string;
  items: string[];
  value: string;
  setValue: (value: string) => void;
}) {
  return (
    <div>
      <h2 className="mb-3 text-xs font-medium uppercase tracking-[0.08em] text-[#9CA3AF]">
        {title}
      </h2>

      <div className="flex flex-wrap gap-3">
        {items.map((item) => (
          <button
            key={item}
            onClick={() => setValue(item)}
            className={`rounded-xl border px-5 py-3 font-semibold transition duration-150 ${
              value === item
                ? "border-[#4F46E5] bg-[#4F46E5] text-white"
                : "border-[#EDEEF2] bg-white text-[#111827] hover:bg-[#EEF2FF] hover:text-[#4F46E5]"
            }`}
          >
            {item}
          </button>
        ))}
      </div>
    </div>
  );
}