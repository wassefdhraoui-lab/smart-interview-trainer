import Navbar from "../../components/Navbar";

export default function ProfilePage() {
  return (
    <>
      <Navbar />

      <main className="min-h-screen bg-[#FFFFFF] px-8 py-12 text-[#111827]">
        <div className="mx-auto max-w-4xl">
          <div className="mb-8">
            <p className="text-sm font-semibold text-[#4F46E5]">Profile</p>

            <h1 className="mt-2 text-[2.5rem] font-extrabold tracking-[-0.02em]">
              Account Settings
            </h1>

            <p className="mt-3 text-lg leading-[1.6] text-[#6B7280]">
              Manage your personal information, password, and interview
              preferences.
            </p>
          </div>

          <section className="space-y-8">
            <div className="rounded-3xl border border-[#EDEEF2] bg-[#F5F6FA] p-8 shadow-sm">
              <h2 className="text-2xl font-bold text-[#111827]">
                Personal Information
              </h2>

              <div className="mt-6 grid gap-4 md:grid-cols-2">
                <input
                  className="rounded-xl border border-[#EDEEF2] bg-white px-4 py-3 text-[#111827] outline-none placeholder:text-[#9CA3AF] focus:border-[#4F46E5]"
                  placeholder="Full Name"
                  defaultValue="Sara Ahmed"
                />

                <input
                  className="rounded-xl border border-[#EDEEF2] bg-white px-4 py-3 text-[#111827] outline-none placeholder:text-[#9CA3AF] focus:border-[#4F46E5]"
                  placeholder="Email"
                  defaultValue="sara@example.com"
                />
              </div>
            </div>

            <div className="rounded-3xl border border-[#EDEEF2] bg-[#F5F6FA] p-8 shadow-sm">
              <h2 className="text-2xl font-bold text-[#111827]">
                Change Password
              </h2>

              <div className="mt-6 grid gap-4 md:grid-cols-2">
                <input
                  className="rounded-xl border border-[#EDEEF2] bg-white px-4 py-3 text-[#111827] outline-none placeholder:text-[#9CA3AF] focus:border-[#4F46E5]"
                  placeholder="Current Password"
                  type="password"
                />

                <input
                  className="rounded-xl border border-[#EDEEF2] bg-white px-4 py-3 text-[#111827] outline-none placeholder:text-[#9CA3AF] focus:border-[#4F46E5]"
                  placeholder="New Password"
                  type="password"
                />
              </div>
            </div>

            <div className="grid gap-8 md:grid-cols-2">
              <div className="rounded-3xl border border-[#EDEEF2] bg-[#F5F6FA] p-8 shadow-sm">
                <h2 className="text-2xl font-bold text-[#111827]">
                  Interview Statistics
                </h2>

                <div className="mt-6 grid grid-cols-2 gap-4">
                  <div className="rounded-2xl border border-[#EDEEF2] bg-white p-5">
                    <p className="text-xs font-medium uppercase tracking-[0.08em] text-[#9CA3AF]">
                      Sessions
                    </p>
                    <h3 className="mt-2 text-[1.75rem] font-bold text-[#111827]">
                      5
                    </h3>
                  </div>

                  <div className="rounded-2xl border border-[#EDEEF2] bg-white p-5">
                    <p className="text-xs font-medium uppercase tracking-[0.08em] text-[#9CA3AF]">
                      Avg Score
                    </p>
                    <h3 className="mt-2 text-[1.75rem] font-bold text-[#10B981]">
                      82%
                    </h3>
                  </div>
                </div>
              </div>

              <div className="rounded-3xl border border-[#EDEEF2] bg-[#F5F6FA] p-8 shadow-sm">
                <h2 className="text-2xl font-bold text-[#111827]">
                  Preferred Categories
                </h2>

                <div className="mt-6 flex flex-wrap gap-3">
                  {["Java", "SQL", "HR", "Algorithms"].map((category) => (
                    <button
                      key={category}
                      className="rounded-xl border border-[#EDEEF2] bg-white px-5 py-3 font-semibold text-[#111827] transition duration-150 hover:bg-[#EEF2FF] hover:text-[#4F46E5]"
                    >
                      {category}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            <div className="flex justify-end gap-4">
              <button className="rounded-xl border border-[#EDEEF2] bg-white px-6 py-3 font-semibold text-[#EF4444] transition hover:bg-red-50">
                Logout
              </button>

              <button className="rounded-xl bg-[#4F46E5] px-6 py-3 font-semibold text-white transition hover:bg-[#6366F1]">
                Save Changes
              </button>
            </div>
          </section>
        </div>
      </main>
    </>
  );
}