"use client";

import { useEffect, useRef, useState } from "react";
import Link from "next/link";
import Navbar from "../../components/Navbar";

type Question = {
  id: number;
  question_text: string;
  user_answer: string;
};

type Session = {
  category: string;
  difficulty: string;
  answer_mode: string;
};

export default function InterviewPage() {
  const canLeave = useRef(false);

  const [sessionId, setSessionId] = useState("");
  const [session, setSession] = useState<Session | null>(null);
  const [questions, setQuestions] = useState<Question[]>([]);
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [answer, setAnswer] = useState("");
  const [message, setMessage] = useState("");

  useEffect(() => {
    async function loadQuestions() {
      const params = new URLSearchParams(window.location.search);
      const id = params.get("sessionId");

      if (!id) {
        setMessage("Session not found.");
        return;
      }

      setSessionId(id);

      try {
        const response = await fetch(
          `http://localhost:5000/interview/sessions/${id}/questions`
        );

        const data = await response.json();

        if (!data.success) {
          setMessage(data.message);
          return;
        }

        if (data.questions.length === 0) {
          setMessage("No matching questions found.");
          return;
        }

        setSession(data.session);
        setQuestions(data.questions);
        setAnswer(data.questions[0].user_answer);
      } catch (error) {
        console.error(error);
        setMessage("Questions could not be loaded.");
      }
    }

    loadQuestions();
  }, []);

  // Browser refresh, close tab or browser back warning.
  useEffect(() => {
    function warnBeforeLeaving(event: BeforeUnloadEvent) {
      if (canLeave.current) {
        return;
      }

      event.preventDefault();
      event.returnValue = "";
    }

    window.addEventListener("beforeunload", warnBeforeLeaving);

    return () => {
      window.removeEventListener(
        "beforeunload",
        warnBeforeLeaving
      );
    };
  }, []);

  // Intercepts links in the interview page, including Navbar links.
  useEffect(() => {
    async function handleLinkClick(event: MouseEvent) {
      const link = (event.target as HTMLElement).closest("a");

      if (!link || !sessionId) {
        return;
      }

      const destination = link.getAttribute("href");

      if (!destination) {
        return;
      }

      event.preventDefault();

      const leave = window.confirm(
        "Do you want to leave the interview? Your session and answers will be deleted."
      );

      if (!leave) {
        return;
      }

      const response = await fetch(
        `http://localhost:5000/interview/sessions/${sessionId}`,
        {
          method: "DELETE",
        }
      );

      const data = await response.json();

      if (data.success) {
        canLeave.current = true;
        window.location.href = destination;
      } else {
        setMessage(data.message);
      }
    }

    document.addEventListener("click", handleLinkClick);

    return () => {
      document.removeEventListener("click", handleLinkClick);
    };
  }, [sessionId]);
  async function saveCurrentAnswer() {
  const lastQuestion =
    currentQuestion === questions.length - 1;

  const result = await saveAnswerToDatabase(lastQuestion);

  if (!result) {
    return;
  }

  if (result.data.completed) {
    canLeave.current = true;

    window.location.href =
      `/feedback?sessionId=${sessionId}`;

    return;
  }

  const nextQuestion = currentQuestion + 1;

  setCurrentQuestion(nextQuestion);
  setAnswer(
    result.updatedQuestions[nextQuestion].user_answer
  );
}
  async function showPreviousQuestion() {
  const result = await saveAnswerToDatabase(false);

  if (!result) {
    return;
  }

  const previousQuestion = currentQuestion - 1;

  setCurrentQuestion(previousQuestion);
  setAnswer(
    result.updatedQuestions[previousQuestion].user_answer
  );
}

  async function saveAnswerToDatabase(completeInterview: boolean) {
  if (!answer.trim()) {
    setMessage("Please enter an answer.");
    return null;
  }

  const question = questions[currentQuestion];

  const response = await fetch(
    "http://localhost:5000/interview/answers",
    {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        session_id: sessionId,
        question_id: question.id,
        question_order: currentQuestion + 1,
        user_answer: answer,
        complete_interview: completeInterview,
      }),
    }
  );

  const data = await response.json();

  if (!data.success) {
    setMessage(data.message);
    return null;
  }

  const updatedQuestions = [...questions];

  updatedQuestions[currentQuestion] = {
    ...question,
    user_answer: answer,
  };

  setQuestions(updatedQuestions);
  setMessage("");

  return {
    data,
    updatedQuestions,
  };
}

  if (!session || questions.length === 0) {
    return (
      <>
        <Navbar />

        <main className="min-h-screen bg-white px-8 py-12 text-center text-[#111827]">
          <p>{message || "Loading questions..."}</p>
        </main>
      </>
    );
  }

  const question = questions[currentQuestion];

  const progress =
    ((currentQuestion + 1) / questions.length) * 100;

  return (
    <>
      <Navbar />

      <main className="min-h-screen bg-white px-8 py-12 pt-30 text-[#111827]">
        <div className="mx-auto max-w-4xl">
          <div className="mb-6 flex items-center justify-between">
            <Link
              href="/dashboard"
              className="font-semibold text-[#4F46E5]"
            >
              ← Exit
            </Link>

            <p className="font-semibold text-[#6B7280]">
              {session.category} · {session.difficulty} · Question{" "}
              {currentQuestion + 1} of {questions.length}
            </p>
          </div>

          <div className="mb-8 h-3 rounded-full bg-[#EDEEF2]">
            <div
              className="h-3 rounded-full bg-[#4F46E5]"
              style={{ width: `${progress}%` }}
            />
          </div>

          <section className="rounded-3xl border border-[#EDEEF2] bg-[#F5F6FA] p-8 shadow-sm">
            <p className="text-sm font-semibold text-[#4F46E5]">
              {session.answer_mode}
            </p>

            <h1 className="mt-3 text-[2.5rem] font-extrabold tracking-[-0.02em]">
              Question {currentQuestion + 1}
            </h1>

            <p className="mt-5 text-xl leading-8 text-[#6B7280]">
              {question.question_text}
            </p>

            <textarea
              value={answer}
              onChange={(event) => setAnswer(event.target.value)}
              placeholder="Type your answer here..."
              className="mt-8 h-44 w-full rounded-2xl border border-[#EDEEF2] bg-white p-4 outline-none focus:border-[#4F46E5]"
            />

            {message && (
              <p className="mt-3 text-sm font-semibold text-red-600">
                {message}
              </p>
            )}

            <div className="mt-8 flex justify-between">
              <button
                type="button"
                onClick={showPreviousQuestion}
                disabled={currentQuestion === 0}
                className="rounded-xl border border-[#EDEEF2] bg-white px-6 py-3 font-semibold disabled:cursor-not-allowed disabled:opacity-40"
              >
                Back
              </button>

              <button
                type="button"
                onClick={saveCurrentAnswer}
                className="rounded-xl bg-[#4F46E5] px-6 py-3 font-semibold text-white transition hover:bg-[#6366F1]"
              >
                {currentQuestion === questions.length - 1
                  ? "Finish Interview"
                  : "Next Question"}
              </button>
            </div>
          </section>
        </div>
      </main>
    </>
  );
}