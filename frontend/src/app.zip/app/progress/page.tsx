"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import Navbar from "../../components/Navbar";
import { useUser } from "../../context/UserContext";

type ProgressData = {
  summary: {
    completed_interviews: number;
    average_score: number;
    best_score: number;
  };
  categoryStats: {
    category: string;
    average_score: number;
    completed_count: number;
  }[];
  scoreHistory: {
    id: number;
    total_score: number;
    completed_at: string;
  }[];
  recentSessions: {
    id: number;
    total_score: number;
    completed_at: string;
    category: string;
    difficulty: string;
  }[];
};

export default function ProgressPage() {
  const { user } = useUser();
  const [progress, setProgress] = useState<ProgressData | null>(null);

  useEffect(() => {
    async function loadProgress() {
      if (!user) return;

      const response = await fetch(
        `http://localhost:5000/progress?userId=${user.id}`
      );

      const data = await response.json();

      if (data.success) {
        setProgress(data);
      }
    }

    loadProgress();
  }, [user]);

  const categoryStats = progress?.categoryStats || [];
  const scoreHistory = progress?.scoreHistory || [];
  const recentSessions = progress?.recentSessions || [];

  const weakestCategory =
    categoryStats.length > 0
      ? categoryStats[categoryStats.length - 1].category
      : "-";

  return (
    <>
      <Navbar />

      <main className="min-h-screen bg-white px-8 py-10 text-[#111827]">
        <div className="mx-auto max-w-5xl">
          <h1 className="text-4xl font-extrabold">Progress Overview</h1>

          <p className="mt-4 text-[#6B7280]">
            Track your improvement, review old interviews, and continue with
            targeted practice.
          </p>

          <section className="mt-8 grid grid-cols-1 gap-4 md:grid-cols-3">
            <SmallCard title="Completed" value={progress?.summary.completed_interviews || 0} />
            <SmallCard title="Average Score" value={`${progress?.summary.average_score || 0}%`} />
            <SmallCard title="Best Score" value={`${progress?.summary.best_score || 0}%`} />
          </section>

          <section className="mt-8 grid grid-cols-1 gap-6 md:grid-cols-2">
            <div className="rounded-3xl border border-[#EDEEF2] bg-[#F5F6FA] p-8 shadow-sm">
              <h2 className="text-2xl font-extrabold">Score over time</h2>

              <div className="mt-6 rounded-2xl bg-white p-6">
                {scoreHistory.length ? (
                  <LineChart data={scoreHistory} />
                ) : (
                  <div className="flex h-64 items-center justify-center text-[#6B7280]">
                    No score history yet.
                  </div>
                )}
              </div>
            </div>

            <div className="rounded-3xl border border-[#EDEEF2] bg-[#F5F6FA] p-8 shadow-sm">
              <h2 className="text-2xl font-extrabold">
                Performance by category
              </h2>

              <div className="mt-6 space-y-5">
                {categoryStats.length ? (
                  categoryStats.map((item) => (
                    <div key={item.category}>
                      <div className="mb-2 flex justify-between text-sm text-[#6B7280]">
                        <span>{item.category}</span>
                        <span>{item.average_score}%</span>
                      </div>

                      <div className="h-3 rounded-full bg-[#EDEEF2]">
                        <div
                          className={`h-3 rounded-full ${
                            item.average_score >= 70
                              ? "bg-[#10B981]"
                              : item.average_score >= 40
                              ? "bg-orange-400"
                              : "bg-red-500"
                          }`}
                          style={{ width: `${item.average_score}%` }}
                        />
                      </div>
                    </div>
                  ))
                ) : (
                  <p className="text-[#6B7280]">No category data yet.</p>
                )}
              </div>
            </div>
          </section>

          <section className="mt-8 flex items-center justify-between rounded-3xl border border-[#EDEEF2] bg-[#F5F6FA] p-8 shadow-sm">
            <div>
              <h2 className="text-2xl font-extrabold">
                Recommended next practice
              </h2>

              <p className="mt-2 text-[#6B7280]">
                {weakestCategory === "-"
                  ? "Complete more interviews to get a recommendation."
                  : `${weakestCategory} is currently your weakest category.`}
              </p>
            </div>

            <Link
              href="/interview-setup"
              className="rounded-xl bg-[#4F46E5] px-6 py-3 font-semibold text-white"
            >
              Practice →
            </Link>
          </section>

          <section className="mt-8 rounded-3xl border border-[#EDEEF2] bg-[#F5F6FA] p-8 shadow-sm">
            <h2 className="text-2xl font-extrabold">Interview history</h2>

            <div className="mt-5 space-y-4">
              {recentSessions.length ? (
                recentSessions.map((session) => (
                  <div
                    key={session.id}
                    className="flex items-center justify-between rounded-xl bg-white p-4"
                  >
                    <div>
                      <p className="font-bold">
                        {session.category} Interview
                      </p>

                      <p className="text-sm text-[#6B7280]">
                        {session.difficulty} ·{" "}
                        {new Date(session.completed_at).toLocaleString()}
                      </p>
                    </div>

                    <div className="flex items-center gap-4">
                      <p
                        className={`font-bold ${
                          session.total_score >= 60
                            ? "text-[#10B981]"
                            : "text-red-500"
                        }`}
                      >
                        {session.total_score}%
                      </p>

                      <Link
                        href={`/feedback?sessionId=${session.id}`}
                        className="rounded-lg bg-[#4F46E5] px-5 py-2 font-semibold text-white"
                      >
                        Review
                      </Link>
                    </div>
                  </div>
                ))
              ) : (
                <p className="rounded-xl bg-white p-4 text-[#6B7280]">
                  No completed interviews yet.
                </p>
              )}
            </div>
          </section>
        </div>
      </main>
    </>
  );
}

function SmallCard({
  title,
  value,
}: {
  title: string;
  value: string | number;
}) {
  return (
    <div className="rounded-2xl border border-[#EDEEF2] bg-[#F5F6FA] p-6 shadow-sm">
      <p className="text-xs font-bold uppercase tracking-widest text-[#9CA3AF]">
        {title}
      </p>

      <p className="mt-3 text-4xl font-extrabold text-[#4F46E5]">
        {value}
      </p>
    </div>
  );
}

function LineChart({
  data,
}: {
  data: {
    id: number;
    total_score: number;
    completed_at: string;
  }[];
}) {
  const width = 520;
  const height = 260;
  const padding = 45;

  const points = data.map((item, index) => {
    const x =
      data.length === 1
        ? width / 2
        : padding +
          (index * (width - padding * 2)) / (data.length - 1);

    const y =
      height -
      padding -
      (item.total_score / 100) * (height - padding * 2);

    return {
      x,
      y,
      score: item.total_score,
    };
  });

  const path = points
    .map((point, index) =>
      index === 0 ? `M ${point.x} ${point.y}` : `L ${point.x} ${point.y}`
    )
    .join(" ");

  return (
    <div>
      <svg viewBox={`0 0 ${width} ${height}`} className="h-72 w-full">
        {[0, 25, 50, 75, 100].map((value) => {
          const y =
            height -
            padding -
            (value / 100) * (height - padding * 2);

          return (
            <g key={value}>
              <line
                x1={padding}
                y1={y}
                x2={width - padding}
                y2={y}
                stroke="#E5E7EB"
                strokeWidth="1"
              />

              <text
                x={10}
                y={y + 4}
                fontSize="11"
                fill="#6B7280"
              >
                {value}%
              </text>
            </g>
          );
        })}

        <path
          d={path}
          fill="none"
          stroke="#4F46E5"
          strokeWidth="4"
          strokeLinecap="round"
          strokeLinejoin="round"
        />

        {points.map((point, index) => (
          <g key={index}>
            <circle
              cx={point.x}
              cy={point.y}
              r="6"
              fill="#4F46E5"
            />

            <circle
              cx={point.x}
              cy={point.y}
              r="10"
              fill="#4F46E5"
              opacity="0.12"
            />

            <text
              x={point.x}
              y={point.y - 14}
              textAnchor="middle"
              fontSize="12"
              fill="#111827"
              fontWeight="bold"
            >
              {point.score}%
            </text>
          </g>
        ))}
      </svg>

      <p className="mt-2 text-center text-sm text-[#6B7280]">
        Last {data.length} completed interviews
      </p>
    </div>
  );
}