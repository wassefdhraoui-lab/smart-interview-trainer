"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import Navbar from "../../components/Navbar";

type SessionFeedback = {
  id: number;
  total_score: number;
  general_feedback: string;
  category: string;
  difficulty: string;
};

type AnswerFeedback = {
  question_order: number;
  question_text: string;
  sample_answer: string;
  user_answer: string;
  score: number;
  feedback: string;
  missed_keywords: string[];
};

export default function FeedbackPage() {
  const [session, setSession] =
    useState<SessionFeedback | null>(null);

  const [answers, setAnswers] =
    useState<AnswerFeedback[]>([]);

  const [message, setMessage] = useState("");

  useEffect(() => {
    async function getFeedback() {
      const params = new URLSearchParams(
        window.location.search
      );

      const sessionId = params.get("sessionId");

      if (!sessionId) {
        setMessage("Session not found.");
        return;
      }

      try {
        const response = await fetch(
          `http://localhost:5000/interview/sessions/${sessionId}/feedback`
        );

        const data = await response.json();

        if (!data.success) {
          setMessage(data.message);
          return;
        }

        setSession(data.session);
        setAnswers(data.answers);
      } catch (error) {
        console.error(error);
        setMessage("Feedback could not be loaded.");
      }
    }

    getFeedback();
  }, []);

  if (!session) {
    return (
      <>
        <Navbar />

        <main className="min-h-screen bg-white px-8 py-12 text-center">
          <p>{message || "Loading feedback..."}</p>
        </main>
      </>
    );
  }

  return (
    <>
      <Navbar />

      <main className="min-h-screen bg-white px-8 py-12 text-[#111827]">
        <div className="mx-auto max-w-4xl">
          <section className="rounded-3xl border border-[#EDEEF2] bg-[#F5F6FA] p-8 shadow-sm">
            <p className="text-sm font-semibold text-[#4F46E5]">
              {session.category} · {session.difficulty}
            </p>

            <h1 className="mt-3 text-4xl font-extrabold">
              Interview Feedback
            </h1>

            <div className="mt-8 rounded-2xl bg-white p-6">
              <p className="text-sm font-semibold uppercase text-[#9CA3AF]">
                Total Score
              </p>

              <p className="mt-2 text-5xl font-extrabold text-[#4F46E5]">
                {session.total_score}
              </p>

              <p className="mt-4 text-lg text-[#6B7280]">
                {session.general_feedback}
              </p>
            </div>
          </section>

          <div className="mt-8 space-y-6">
            {answers.map((answer) => (
              <section
                key={answer.question_order}
                className="rounded-2xl border border-[#EDEEF2] bg-white p-6 shadow-sm"
              >
                <div className="flex items-center justify-between">
                  <h2 className="text-xl font-bold">
                    Question {answer.question_order}
                  </h2>

                  <span className="rounded-lg bg-[#EEF2FF] px-3 py-2 font-bold text-[#4F46E5]">
                    {answer.score}/100
                  </span>
                </div>

                <p className="mt-4 font-semibold">
                  {answer.question_text}
                </p>

                <div className="mt-4 rounded-xl bg-[#F5F6FA] p-4">
                  <p className="text-xs font-semibold uppercase text-[#9CA3AF]">
                    Your Answer
                  </p>

                  <p className="mt-2">
                    {answer.user_answer}
                  </p>
                </div>

                <p className="mt-4 text-[#6B7280]">
                  {answer.feedback}
                </p>

                {answer.missed_keywords &&
                  answer.missed_keywords.length > 0 && (
                    <div className="mt-4">
                      <p className="text-sm font-semibold">
                        Missing keywords :) 
                      </p>
                      <p className="mt-2 text-[#111827]">
                        Better answer:
                        {answer.sample_answer}
                      </p>

                      <div className="mt-2 flex flex-wrap gap-2">
                        {answer.missed_keywords.map(
                          (keyword) => (
                            <span
                              key={keyword}
                              className="rounded-lg bg-red-50 px-3 py-1 text-sm text-red-600"
                            >
                              {keyword}
                            </span>
                          )
                        )}
                      </div>
                    </div>
                  )}
              </section>
            ))}
          </div>

          <div className="mt-8 flex justify-end">
            <Link
              href="/dashboard"
              className="rounded-xl bg-[#4F46E5] px-6 py-3 font-semibold text-white"
            >
              Back to Dashboard
            </Link>
          </div>
        </div>
      </main>
    </>
  );
}