"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import Navbar from "../../components/Navbar";
import { useUser } from "../../context/UserContext";

type InterviewOption = {
  id: number;
  name: string;
};

const questionCounts: InterviewOption[] = [
  {
    id: 3,
    name: "3",
  },
  {
    id: 5,
    name: "5",
  },
  {
    id: 10,
    name: "10",
  },
];

export default function InterviewSetupPage() {
  const router = useRouter();
  const { user } = useUser();

  // Options loaded from PostgreSQL
  const [categories, setCategories] = useState<InterviewOption[]>([]);
  const [difficulties, setDifficulties] = useState<InterviewOption[]>([]);
  const [answerModes, setAnswerModes] = useState<InterviewOption[]>([]);

  // Selected option IDs
  const [categoryId, setCategoryId] = useState<number | null>(null);
  const [difficultyId, setDifficultyId] = useState<number | null>(null);
  const [questionCount, setQuestionCount] = useState(5);
  const [answerModeId, setAnswerModeId] = useState<number | null>(null);

  const [error, setError] = useState("");
  const [loadingOptions, setLoadingOptions] = useState(true);
  const [startingInterview, setStartingInterview] = useState(false);

  // Load categories, difficulties and answer modes once
  // when the page opens.
  useEffect(() => {
    async function loadInterviewOptions() {
      try {
        setError("");

        const response = await fetch(
          "http://localhost:5000/interview/options"
        );

        const data = await response.json();

        if (!response.ok || !data.success) {
          setError(
            data.message || "Interview options could not be loaded."
          );

          return;
        }

        setCategories(data.categories);
        setDifficulties(data.difficulties);
        setAnswerModes(data.answerModes);

        // Select the first database option automatically.
        setCategoryId(data.categories[0]?.id ?? null);
        setDifficultyId(data.difficulties[0]?.id ?? null);
        setAnswerModeId(data.answerModes[0]?.id ?? null);
      } catch (error) {
        console.error("Load interview options error:", error);
        setError("Could not connect to the backend.");
      } finally {
        setLoadingOptions(false);
      }
    }

    loadInterviewOptions();
  }, []);

  // Runs only when the user clicks Start Interview.
  async function handleStartInterview() {
    if (!user) {
      setError("User data is still loading.");

      return;
    }

    if (
      categoryId === null ||
      difficultyId === null ||
      answerModeId === null
    ) {
      setError("Please select all interview options.");

      return;
    }

    try {
      setError("");
      setStartingInterview(true);

      const response = await fetch(
        "http://localhost:5000/interview/sessions",
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            user_id: user.id,
            category_id: categoryId,
            difficulty_id: difficultyId,
            question_count: questionCount,
            answer_mode_id: answerModeId,
          }),
        }
      );

      const data = await response.json();
      console.log("Backend response:", data);

      if (!response.ok || !data.success) {
        setError(data.message || "Session could not be created.");

        return;
      }

      router.push(`/interview?sessionId=${data.session.id}`);
    } catch (error) {
      console.error("Create interview session error:", error);
      setError("Could not connect to the backend.");
    } finally {
      setStartingInterview(false);
    }
  }

  return (
    <>
      <Navbar />

      <main className="min-h-screen bg-[#FFFFFF] px-8 py-12 text-[#111827]">
        <div className="mx-auto max-w-3xl rounded-3xl border border-[#EDEEF2] bg-[#F5F6FA] p-8 shadow-sm">
          <Link
            href="/dashboard"
            className="text-sm font-semibold text-[#4F46E5]"
          >
            ← Cancel
          </Link>

          <h1 className="mt-6 text-[2.5rem] font-extrabold tracking-[-0.02em] text-[#111827]">
            Interview Setup
          </h1>

          {loadingOptions ? (
            <p className="mt-8 text-[#6B7280]">
              Loading interview options...
            </p>
          ) : (
            <div className="mt-8 space-y-8">
              <OptionGroup
                title="Interview Category"
                items={categories}
                selectedId={categoryId}
                setSelectedId={setCategoryId}
              />

              <OptionGroup
                title="Difficulty"
                items={difficulties}
                selectedId={difficultyId}
                setSelectedId={setDifficultyId}
              />

              <OptionGroup
                title="Number of Questions"
                items={questionCounts}
                selectedId={questionCount}
                setSelectedId={setQuestionCount}
              />

              <OptionGroup
                title="Answer Mode"
                items={answerModes}
                selectedId={answerModeId}
                setSelectedId={setAnswerModeId}
              />
            </div>
          )}

          {error && (
            <div className="mt-6 rounded-xl border border-red-200 bg-red-50 px-4 py-3 text-sm font-medium text-red-600">
              {error}
            </div>
          )}

          <div className="mt-10 flex justify-end gap-4">
            <Link
              href="/dashboard"
              className="rounded-xl border border-[#EDEEF2] bg-white px-6 py-3 font-semibold text-[#111827] transition hover:bg-[#F5F6FA]"
            >
              Cancel
            </Link>

            <button
              type="button"
              onClick={handleStartInterview}
              disabled={
                loadingOptions ||
                startingInterview ||
                !user ||
                categoryId === null ||
                difficultyId === null ||
                answerModeId === null
              }
              className="rounded-xl bg-[#4F46E5] px-6 py-3 font-semibold text-white transition hover:bg-[#6366F1] disabled:cursor-not-allowed disabled:opacity-50"
            >
              {startingInterview ? "Starting..." : "Start Interview"}
            </button>
          </div>
        </div>
      </main>
    </>
  );
}

function OptionGroup({
  title,
  items,
  selectedId,
  setSelectedId,
}: {
  title: string;
  items: InterviewOption[];
  selectedId: number | null;
  setSelectedId: (id: number) => void;
}) {
  return (
    <div>
      <h2 className="mb-3 text-xs font-medium uppercase tracking-[0.08em] text-[#9CA3AF]">
        {title}
      </h2>

      <div className="flex flex-wrap gap-3">
        {items.map((item) => (
          <button
            key={item.id}
            type="button"
            onClick={() => setSelectedId(item.id)}
            className={`rounded-xl border px-5 py-3 font-semibold transition duration-150 ${
              selectedId === item.id
                ? "border-[#4F46E5] bg-[#4F46E5] text-white"
                : "border-[#EDEEF2] bg-white text-[#111827] hover:bg-[#EEF2FF] hover:text-[#4F46E5]"
            }`}
          >
            {item.name}
          </button>
        ))}
      </div>
    </div>
  );
}