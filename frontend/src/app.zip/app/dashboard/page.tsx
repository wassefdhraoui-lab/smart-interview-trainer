"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import Navbar from "../../components/Navbar";
import { useUser } from "../../context/UserContext";

type ProgressData = {
  summary: {
    completed_interviews: string;
    average_score: number | null;
    best_score: number | null;
  };
  categoryStats?: {
    category: string;
    average_score: number;
    completed_count: string;
  }[];
  recentSessions?: {
    id: number;
    total_score: number;
    category: string;
    difficulty: string;
  }[];
};

const categories = ["Java", "SQL", "HR", "Algorithms", "Web Development"];

export default function DashboardPage() {
  const { user } = useUser();
  const [progress, setProgress] = useState<ProgressData | null>(null);
  const [selectedCategory, setSelectedCategory] = useState("Java");

  useEffect(() => {
    async function loadProgress() {
      if (!user) return;

      const response = await fetch(
        `http://localhost:5000/progress?userId=${user.id}`
      );

      const data = await response.json();

      if (data.success) {
        setProgress(data);
      }
    }

    loadProgress();
  }, [user]);

  const categoryStats = progress?.categoryStats || [];
  const recentSessions = progress?.recentSessions || [];

  const bestCategory =
    categoryStats.length > 0 ? categoryStats[0].category : "-";

  const weakestCategory =
    categoryStats.length > 0
      ? categoryStats[categoryStats.length - 1].category
      : "-";

  const lastInterview = recentSessions[0];

  return (
    <>
      <Navbar />

      <main className="min-h-screen bg-white px-8 py-10 text-[#111827]">
        <div className="mx-auto max-w-6xl">
          <section className="rounded-3xl border border-[#EDEEF2] bg-[#F5F6FA] p-8 shadow-sm">
            <div className="flex flex-col gap-8 md:flex-row md:items-center md:justify-between">
              <div className="flex items-center gap-6">
                {user?.avatar ? (
                  <img
                    src={`/${user.avatar}`}
                    alt="User avatar"
                    className="h-28 w-28 rounded-full border-4 border-white object-cover shadow-lg"
                  />
                ) : (
                  <div className="flex h-28 w-28 items-center justify-center rounded-full border-4 border-white bg-[#EEF2FF] text-5xl shadow-lg">
                    👤
                  </div>
                )}

                <div>
                  <p className="text-sm font-bold uppercase tracking-widest text-[#4F46E5]">
                    Smart Interview Trainer
                  </p>

                  <h1 className="mt-2 text-4xl font-extrabold">
                    Welcome back, {user?.name || "User"} 👋
                  </h1>

                  <p className="mt-3 max-w-xl text-[#6B7280]">
                    Continue improving your interview skills with focused
                    questions, saved feedback, and progress tracking.
                  </p>

                  <div className="mt-4 flex flex-wrap gap-3 text-sm font-semibold text-[#6B7280]">
                    

                    <span>
                      Last:{" "}
                      <strong className="text-[#111827]">
                        {lastInterview
                          ? `${lastInterview.category} · ${lastInterview.difficulty}`
                          : "No interview yet"}
                      </strong>
                    </span>
                  </div>
                </div>
              </div>

              <div className="flex gap-3">
                <Link
                  href="/interview-setup"
                  className="rounded-xl bg-[#4F46E5] px-6 py-3 font-semibold text-white transition hover:bg-[#6366F1]"
                >
                  Start Interview
                </Link>

                <Link
                  href="/progress"
                  className="rounded-xl border border-[#EDEEF2] bg-white px-6 py-3 font-semibold text-[#111827]"
                >
                  View Progress
                </Link>
              </div>
            </div>
          </section>

          <section className="mt-8 grid grid-cols-1 gap-5 md:grid-cols-4">
            <Card
              title="AVG SCORE"
              value={`${progress?.summary.average_score || 0}%`}
              green
            />

            <Card
              title="COMPLETED"
              value={progress?.summary.completed_interviews || "0"}
            />

            <Card title="BEST CATEGORY" value={bestCategory} green />

            <Card title="WEAKEST CATEGORY" value={weakestCategory} red />
          </section>

          <section className="mt-8 rounded-3xl border border-[#EDEEF2] bg-[#F5F6FA] p-8 shadow-sm">
            <h2 className="text-2xl font-extrabold">
              Choose Practice Category
            </h2>

            <div className="mt-6 flex flex-wrap gap-3">
              {categories.map((category) => (
                <button
                  key={category}
                  type="button"
                  onClick={() => setSelectedCategory(category)}
                  className={`rounded-xl px-5 py-3 font-semibold transition ${
                    selectedCategory === category
                      ? "bg-[#4F46E5] text-white"
                      : "bg-white text-[#111827] hover:bg-[#EEF2FF] hover:text-[#4F46E5]"
                  }`}
                >
                  {category}
                </button>
              ))}
            </div>

            <div className="mt-6 flex flex-col gap-4 rounded-2xl bg-white p-6 md:flex-row md:items-center md:justify-between">
              <div>
                <p className="text-xs font-bold uppercase text-[#4F46E5]">
                  Selected Category
                </p>

                <h3 className="mt-2 text-2xl font-extrabold">
                  {selectedCategory} Interview Practice
                </h3>

                <p className="mt-2 text-[#6B7280]">
                  Focused practice questions for this category.
                </p>
              </div>

              <Link
                href="/interview-setup"
                className="rounded-xl bg-[#4F46E5] px-6 py-3 text-center font-semibold text-white"
              >
                Start Setup
              </Link>
            </div>
          </section>

          <section className="mt-8 rounded-3xl border border-[#EDEEF2] bg-[#F5F6FA] p-8 shadow-sm">
            <div className="flex items-center justify-between">
              <h2 className="text-2xl font-extrabold">Recent Interviews</h2>

              <Link href="/progress" className="font-semibold text-[#4F46E5]">
                View all →
              </Link>
            </div>

            <div className="mt-5 space-y-3">
              {recentSessions.length ? (
                recentSessions.map((session) => (
                  <div
                    key={session.id}
                    className="flex items-center justify-between rounded-xl bg-white p-4"
                  >
                    <div>
                      <p className="font-bold">
                        {session.category} Interview
                      </p>

                      <p className="text-sm text-[#6B7280]">
                        {session.difficulty}
                      </p>
                    </div>

                    <div className="flex items-center gap-4">
                      <p
                        className={`font-bold ${
                          session.total_score >= 60
                            ? "text-[#10B981]"
                            : "text-red-500"
                        }`}
                      >
                        {session.total_score}%
                      </p>

                      <Link
                        href={`/feedback?sessionId=${session.id}`}
                        className="rounded-lg bg-[#4F46E5] px-4 py-2 font-semibold text-white"
                      >
                        Review
                      </Link>
                    </div>
                  </div>
                ))
              ) : (
                <p className="rounded-xl bg-white p-4 text-[#6B7280]">
                  No completed interviews yet.
                </p>
              )}
            </div>
          </section>
        </div>
      </main>
    </>
  );
}

function Card({
  title,
  value,
  green,
  red,
}: {
  title: string;
  value: string | number;
  green?: boolean;
  red?: boolean;
}) {
  return (
    <div className="rounded-2xl border border-[#EDEEF2] bg-white p-6 shadow-sm">
      <p className="text-xs font-bold uppercase tracking-widest text-[#9CA3AF]">
        {title}
      </p>

      <p
        className={`mt-4 text-3xl font-extrabold ${
          green
            ? "text-[#10B981]"
            : red
            ? "text-red-500"
            : "text-[#111827]"
        }`}
      >
        {value}
      </p>
    </div>
  );
}