"use client";

import { useUser } from "../context/UserContext";

const avatars = ["hacker.png", "astronaut.png", "woman.png", "character.png"];

export default function NavbarAvatar() {
  const { user, updateAvatar } = useUser();

  return (
    <div className="group relative">
      <div className="h-11 w-11 overflow-hidden rounded-full border border-[#EDEEF2] bg-[#F5F6FA]">
        {user?.avatar && (
          <img
            src={`/${user.avatar}`}
            alt="User avatar"
            className="h-full w-full object-cover"
          />
        )}
      </div>

      <div className="invisible absolute right-0 top-12 z-50 w-64 rounded-2xl border border-[#EDEEF2] bg-white p-4 opacity-0 shadow-xl transition group-hover:visible group-hover:opacity-100">
        <p className="mb-3 text-sm font-semibold text-[#111827]">
          Choose avatar
        </p>

        <div className="grid grid-cols-4 gap-3">
          {avatars.map((avatar) => (
            <button
              key={avatar}
              onClick={() => updateAvatar(avatar)}
              className="h-12 w-12 overflow-hidden rounded-full border border-[#EDEEF2] transition hover:scale-105"
            >
              <img
                src={`/${avatar}`}
                alt="Avatar option"
                className="h-full w-full object-cover"
              />
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}