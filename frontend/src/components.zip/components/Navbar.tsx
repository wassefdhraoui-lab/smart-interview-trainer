"use client";

import Link from "next/link";
import NavbarAvatar from "./NavbarAvatar";

type NavbarProps = {
  avatar?: string;
};

const themes = [
  {
    name: "Blue",
    color: "#1D4ED8",
    values: ["#1E3A8A", "#1D4ED8", "#2563EB", "#3B82F6", "#DBEAFE", "#EFF6FF"],
  },
  {
    name: "Cyan",
    color: "#0891B2",
    values: ["#164E63", "#0E7490", "#0891B2", "#06B6D4", "#CFFAFE", "#ECFEFF"],
  },
  {
    name: "Violet",
    color: "#7C3AED",
    values: ["#4C1D95", "#6D28D9", "#7C3AED", "#8B5CF6", "#EDE9FE", "#F5F3FF"],
  },
  {
    name: "Emerald",
    color: "#059669",
    values: ["#064E3B", "#047857", "#059669", "#10B981", "#D1FAE5", "#ECFDF5"],
  },
];

export default function Navbar({ avatar = "" }: NavbarProps) {
  function changeTheme(values: string[]) {
    const root = document.documentElement;

    root.style.setProperty("--brand-900", values[0]);
    root.style.setProperty("--brand-700", values[1]);
    root.style.setProperty("--brand-600", values[2]);
    root.style.setProperty("--brand-500", values[3]);
    root.style.setProperty("--brand-100", values[4]);
    root.style.setProperty("--brand-50", values[5]);
  }

  return (
    <>
      <nav className="fixed left-0 top-0 z-50 w-full border-b border-[#E6EBF2] bg-white/95 backdrop-blur-sm">
        <div className="pointer-events-none absolute right-0 top-0 h-full w-80 opacity-40">
          <div className="absolute right-10 top-3 h-20 w-64 rounded-full border border-[var(--brand-100)]" />
          <div className="absolute right-0 top-6 h-20 w-72 rounded-full border border-[var(--brand-100)]" />
          <div className="absolute right-24 top-10 h-16 w-56 rounded-full border border-[var(--brand-100)]" />
        </div>

        <div className="relative mx-auto flex max-w-7xl items-center justify-between px-8 py-4">
          <Link href="/" className="text-xl font-bold text-[#0F172A]">
            Smart Interview Trainer
          </Link>

          <div className="flex items-center gap-6">
            <Link href="/dashboard" className="font-semibold text-[#64748B]">
              Dashboard
            </Link>

            <Link href="/interview-setup" className="font-semibold text-[#64748B]">
              Practice
            </Link>

            <Link href="/progress" className="font-semibold text-[#64748B]">
              Progress
            </Link>

            <div className="flex items-center gap-2">
              {themes.map((theme) => (
                <button
                  key={theme.name}
                  type="button"
                  title={theme.name}
                  onMouseEnter={() => changeTheme(theme.values)}
                  onClick={() => changeTheme(theme.values)}
                  className="h-5 w-5 rounded-full border border-white shadow"
                  style={{ backgroundColor: theme.color }}
                />
              ))}
            </div>

            <span>🔔</span>

            <NavbarAvatar />

            <Link
              href="/login"
              className="rounded-xl bg-[var(--brand-700)] px-5 py-3 font-semibold text-white transition hover:bg-[var(--brand-600)]"
            >
              Login
            </Link>
          </div>
        </div>
      </nav>

      <div className="h-[90px]" />
    </>
  );
}