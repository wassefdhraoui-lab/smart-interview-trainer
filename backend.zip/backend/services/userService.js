
import pool from "../database/db.js";

export async function getUserById(userId) {
  const result = await pool.query(
    "SELECT id, name, email, avatar FROM users WHERE id = $1",
    [userId]
  );

  if (result.rows.length === 0) {
    return {
      success: false,
      message: "User not found",
    };
  }

  return {
    success: true,
    user: result.rows[0],
  };
}

export async function updateUserAvatar(userId, avatar) {
  const result = await pool.query(
    "UPDATE users SET avatar = $1 WHERE id = $2 RETURNING id, name, email, avatar",
    [avatar, userId]
  );

  if (result.rows.length === 0) {
    return {
      success: false,
      message: "User not found",
    };
  }

  return {
    success: true,
    message: "Avatar updated",
    user: result.rows[0],
  };
}