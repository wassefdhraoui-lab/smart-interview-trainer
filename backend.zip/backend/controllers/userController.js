import { getUserById, updateUserAvatar } from "../services/userService.js";

export async function getCurrentUser(req, res) {
  const userId = req.query.userId;

  const result = await getUserById(userId);

  res.json(result);
}

export async function updateAvatar(req, res) {
  const userId = req.body.userId;
  const avatar = req.body.avatar;

  const result = await updateUserAvatar(userId, avatar);

  res.json(result);
}