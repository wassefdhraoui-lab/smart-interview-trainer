import express from "express";
import { GetdashboardData } from "../controllers/dashboardController.js";

const router = express.Router();


// GET /dashboard
router.get("/", GetdashboardData);

export default router;