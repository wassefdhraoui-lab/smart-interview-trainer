import express from "express";
import { getCurrentUser, updateAvatar } from "../controllers/userController.js";

const router = express.Router();

router.get("/me", getCurrentUser);
router.patch("/avatar", updateAvatar);

export default router;